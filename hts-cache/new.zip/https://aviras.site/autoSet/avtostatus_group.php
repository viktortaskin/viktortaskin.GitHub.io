<!DOCTYPE html>
<html lang="ru" class="no-js">
<head>

  <title>Aviras.Site • Авто Статус в группу</title>
  
  <!-- [Meta] -->
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta content="width=device-width, initial-scale=0.7" name="viewport" />
  <meta http-equiv="pragma" content="no-cache"/>
  <meta name="description" content="Скрипты для ВКонтакте, Авто-статус ВК, WALLBOT для вконтакте,статусы для вконтакте,бот для вконтакте,скрипты для вк,меняющиеся статусы вк, настенные бот вк,скрипт для очистки стены вконтакте,скрипты автостатусов вконтакте,php скрипты для вконтакте,API сервисы вконтакте,автоустановка автостатуса вконтакте,как сделать авто-статус вконтакте,php скрипты для вконтакте.">
  <meta name="keywords" content="Скрипты для ВКонтакте, Авто-статус ВК, WALLBOT для вконтакте,статусы для вконтакте,бот для вконтакте,скрипты для вк,меняющиеся статусы вк, настенные бот вк,скрипт для очистки стены вконтакте,скрипты автостатусов вконтакте,php скрипты для вконтакте,API сервисы вконтакте,автоустановка автостатуса вконтакте,как сделать авто-статус вконтакте,php скрипты для вконтакте.">  
  <meta name="author" content="vk.com/mr.kurtphop">
  <meta name="google-site-verification" content="H31vNPYP3j2ipbbuD71fEF9OcwVh_-_DWrl0kjp3jGI" />
  <meta name="yandex-verification" content="7b6a28efbaa056f5" />
  <!-- [Meta End] -->
  
  <!-- [Link] -->
  <link href="/resources/css/1.css" rel="stylesheet" type="text/css"/>
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/pace-theme-minimal.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/progress_bar.css" rel="stylesheet" type="text/css"/>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/components-md.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/components-themes-md.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/plugins-md.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/page-layouts.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/themes/cyan.css" rel="stylesheet" type="text/css" />
  <link id="icon" rel="shortcut icon" href="/resources/images/favicon.ico"/>
  <!-- [Link end] -->
  
  <!-- [Script] -->
  <script src="/resources/css/pace.min.js" type="text/javascript"></script>
  <script src="/resources/js/jquery.min.js" type="text/javascript"></script>
  <script src="/resources/js/show.js" type="text/javascript"></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <!-- [Script end] -->
  
  <script id="chatBroEmbedCode">/* Chatbro Widget Embed Code Start */function ChatbroLoader(chats,async){async=!1!==async;var params={embedChatsParameters:chats instanceof Array?chats:[chats],lang:navigator.language||navigator.userLanguage,needLoadCode:'undefined'==typeof Chatbro,embedParamsVersion:localStorage.embedParamsVersion,chatbroScriptVersion:localStorage.chatbroScriptVersion},xhr=new XMLHttpRequest;xhr.withCredentials=!0,xhr.onload=function(){eval(xhr.responseText)},xhr.onerror=function(){console.error('Chatbro loading error')},xhr.open('GET','//www.chatbro.com/embed.js?'+btoa(unescape(encodeURIComponent(JSON.stringify(params)))),async),xhr.send()}/* Chatbro Widget Embed Code End */ChatbroLoader({encodedChatId: '9fkE'});</script>
</head>
<body id="all" class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo page-container-bg-solid">
<body class="page-md page-header-fixed page-sidebar-closed-hide-logo">
  <div class="page-header md-shadow-z-1-i navbar navbar-fixed-top">
    <div class="page-header-inner">
	      <div class="page-logo"><a href="/"><img src="/resources/images/logo.png" alt="logo" class="logo-default"/></a>
        <div class="menu-toggler sidebar-toggler"></div></div>
		<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"></a>
        	<div class="hor-menu hidden-xs hidden-sm"><ul class="nav navbar-nav"></ul></div>           
		   <div class="page-top">
	<div class="hor-menu hor-menu-light hidden-xs"></div>

	    	      <div class="page-top">
        <div class="top-menu">
        <ul class="nav navbar-nav pull-right" style="margin-top: 10%"> <a class="btn blue btn-circle animated shake" href="/data/auth.php"><i class="fa fa-vk"></i> Авторизация</a> </ul>          </div>
		</ul>
	</ul>
</div>
      </div>
    </div>
     </div><div class="clearfix"></div>
  <div class="page-container">
    <div class="page-sidebar-wrapper">
      <div class="page-sidebar md-shadow-z-2-i navbar-collapse collapse">
        <ul class="page-sidebar-menu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
          <li class=""><a href="/"><i class="fa fa-tv"></i><span class="title"> Главная</span><span class=" title"></span></a></li>
		  <li class=""><a href="/pages/insta"><i class="fa fa-instagram"></i><span class=" title"> Накрутка лайков</span></a></li>
          <li class=""><a href="/pages/help.php"><i class="fa fa-info-circle"></i><span class="title"> Помощь</span></a></li>
		  <li class=""><a href="/pages/unblocktel.php"><i class="fa fa-telegram"></i><span class="title"> Unblock Telegram</span></a></li>
		   <li class=""><a href="/pages/news/"><i class="fa fa-tachometer"></i><span class="title"> Новости</span></a></li>
		    <li class=""><a href="/pages/status"><i class="fa fa-stack-overflow"></i><span class="title"> Состояние платформы</span></a></li>
		  <li class=""><a href="/pages/token.php"><i class="fa fa-cogs" aria-hidden="true"></i><span class="title"> Токены</span></a></li>
          <li class=""><a href="/pages/api_vk.php"><i class="fa fa-vk"></i><span class="title"> API Вконтакте</span></a></li>
          <li class="">
		<li class="nav-item active open animated fadeIn">
			<a href="#autoSet" class="nav-link nav-toggle waves-effect"><i class="fa fa-database"></i>
			<span class="title">Установка</span>
			<span class="arrow open"></span>
		</a>
		<ul class="sub-menu" style="display: block;">
			<li><a href="/autoSet/avtostatus.php"><i class="fa fa-chevron-right"></i> <i class="fa fa-commenting-o"></i> Авто-Статус</a></li><li><a href="/autoSet/photo/"><i class="fa fa-chevron-right"></i> <i class="fa fa-camera"></i> Бесконечная накрутка фото <span class="badge badge-success">NEW</span></a></li><li><a href="/autoSet/obl/"><i class="fa fa-chevron-right"></i> <i class="fa fa-address-card-o"></i> Динамическая обложка  <span class="badge badge-success">NEW</span></a></li><li><a href="/autoSet/vip/"><i class="fa fa-chevron-right"></i> <i class="fa fa-diamond"></i> VIP-Авто-Статус  <span class="badge badge-danger">Free</span></a></li><li><a href="/autoSet/avtostatus_group.php"><i class="fa fa-chevron-right"></i> <i class="fa fa-comments-o"></i> Авто-Статус в группу</a></li><li><a href="/autoSet/liker.php"><i class="fa fa-chevron-right"></i> <i class="fa fa-heart"></i> Лайкер</a></li><li><a href="/autoSet/online.php"><i class="fa fa-chevron-right"></i> <i class="fa fa-clock-o"></i> Вечный онлайн</a></li><li><a href="/autoSet/func.php"><i class="fa fa-chevron-right"></i> <i class="fa fa-cogs"></i> Функции</a></li>	  </ul></li>
          <li class="">
		              <a><span class="arrow"></span><i class="fa fa-file-code-o"></i><span class="title"> Скрипты</span></a>
              <ul class="sub-menu">
                <li><a href="/pages/files.php?stats"><i class="fa fa-chevron-right"></i> Авто-Статусы</a></li>
                <li><a href="/pages/files.php?scripts"><i class="fa fa-chevron-right"></i> Прочие скрипты</a></li>
			</ul>
          </li>
		              
             <li class="">  
              <a><span class="arrow"></span><i class="fa fa-bomb"></i><span class="title"> Прочее</span></a>   
              <ul class="sub-menu" style="display: none;">
                                  <li><a href="/pages/MegaLook"><i class="fa fa-chevron-right"></i> Педик с табличкой</a></li>
								    <li class=""><a href="/pages/YT"><i class="fa fa-chevron-right"></i> Качаем видео с YouTube</a></li>
              </ul>
			  </li>
          <li class="heading"><h3 class="uppercase">Другое</h3></li>
          <li class=""><a href="#"><i class="fa fa-info"></i><span class="title"> Приватки</span></a></li>
		  <li>
		  <a href='javascript:(function(){function h(){var e=document.createElement("link");e.setAttribute("type","text/css");e.setAttribute("rel","stylesheet");e.setAttribute("href",l);e.setAttribute("class",c);document.body.appendChild(e)}function p(){var e=document.getElementsByClassName(c);for(var t=0;t<e.length;t++){document.body.removeChild(e[t])}}function d(){var e=document.createElement("div");e.setAttribute("class",f);document.body.appendChild(e);setTimeout(function(){document.body.removeChild(e)},100)}function v(e){return{height:e.offsetHeight,width:e.offsetWidth}}function m(i){var s=v(i);return s.height>e&amp;&amp;s.height<n&amp;&amp;s.width>t&amp;&amp;s.width<r}function g(e){var t=e;var n=0;while(!!t){n+=t.offsetTop;t=t.offsetParent}return n}function y(){var e=document.documentElement;if(!!window.innerWidth){return window.innerHeight}else if(e&amp;&amp;!isNaN(e.clientHeight)){return e.clientHeight}return 0}function b(){if(window.pageYOffset){return window.pageYOffset}return Math.max(document.documentElement.scrollTop,document.body.scrollTop)}function S(e){var t=g(e);return t>=E&amp;&amp;t<=w+E}function x(){var e=document.createElement("audio");e.setAttribute("class",c);e.src=i;e.loop=false;var t=false,n=false,r=false;e.addEventListener("timeupdate",function(){var i=e.currentTime,s=D,o=s.length,u;if(i>=.5&amp;&amp;!t){t=true;T(_)}if(i>=15.5&amp;&amp;!n){n=true;k();d();for(u=0;u<o;u++){N(s[u])}}if(e.currentTime>=28.4&amp;&amp;!r){r=true;C()}},true);e.addEventListener("ended",function(){k();p()},true);e.innerHTML="<p>If you are reading this, it is because your browser does not support the audio element. We recommend that you get a new browser.</p>";document.body.appendChild(e);e.play()}function T(e){e.className+=" "+s+" "+u}function N(e){e.className+=" "+s+" "+a[Math.floor(Math.random()*a.length)]}function C(){var e=document.getElementsByClassName(s);for(var t=0;t<e.length;){e[t].className=e[t].className.replace(s,o)}s=o}function k(){var e=document.getElementsByClassName(s);var t=new RegExp("\\b"+s+"\\b");for(var n=0;n<e.length;){e[n].className=e[n].className.replace(t,"")}}var e=30;var t=30;var n=1000;var r=1000;var i="//s3.amazonaws.com/moovweb-marketing/playground/harlem-shake.ogg";var s="mw-harlem_shake_me";var o="mw-harlem_shake_slow";var u="im_first";var a=["im_drunk","im_baked","im_trippin","im_blown"];var f="mw-strobe_light";var l="//s3.amazonaws.com/moovweb-marketing/playground/harlem-shake-style.css";var c="mw_added_css";var w=y();var E=b();var L=document.getElementsByTagName("*"),A=L.length,O,M;var _=null;for(O=0;O<A;O++){M=L[O];if(m(M)){if(S(M)){_=M;break}}}if(M===null){console.warn("Could not find a node of the right size. Please try a different page.");return}h();x();var D=[];for(O=0;O<A;O++){M=L[O];if(m(M)){D.push(M)}}})()'>
		  <i class="fa fa-code"></i><span class="title"> Сломать сайт</span></a></li>
		  <li class="waves-effect"><a class=""><i class="fa fa-battery-quarter"></i><span class="title "> Нагрузка: 2.9  </span><span class=""></span></a></li>
              </ul>
          </li>
        </ul>
      </div>
 <!-- Yandex.Metrika counter -->
<script type="text/javascript" >
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter46959063 = new Ya.Metrika({
                    id:46959063,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/46959063" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
    </div>
  <script>reqapi='/data/api.php';</script>
  
  <div class="page-content-wrapper">
    <div class="page-content animated fadeInUp">
  <div id="pageinfo"></div>
  
  <script>
  jQuery(document).ready(function(){
      Backbones.init();
      Layout.init();
      Demo.init();
      Index.init();
  });
  </script>
</body>
</html><div class="col-md-12"><div class="note note-danger note-shadow">Для использования данного раздела нужно авторизироваться</div></div>
  <script src="/resources/js/code.js?v=1"></script>   
  <script src="/resources/js/jquery-migrate.min.js" type="text/javascript"></script>
  <script src="/resources/js/jquery-ui.min.js" type="text/javascript"></script>
  <script src="/resources/js/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
  <script src="/resources/js/jquery.uniform.min.js" type="text/javascript"></script>
  <script src="/resources/js/backbones.js" type="text/javascript"></script>
  <script src="/resources/js/page-layouts.js" type="text/javascript"></script>
  <script src="/resources/js/demo.js" type="text/javascript"></script>
  <script src="/resources/js/landing.js" type="text/javascript"></script>
  <script src="/resources/js/func.js?191209" type="text/javascript"></script>
  <script src="/resources/js/jquery.min.js" type="text/javascript"></script>
  <script src="/resources/js/bootstrap.min.js" type="text/javascript"></script>
  <script src="/resources/js/jquery.slimscroll.min.js" type="text/javascript"></script>
  <!--<script src="/resources/js/layout.js" type="text/javascript"></script> FIX MENU-->
  
  
  <script>new WOW().init();</script>

<script asyns type="text/javascript">
(function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter38589325 = new Ya.Metrika({ id:38589325, clickmap:true, trackLinks:true, accurateTrackBounce:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks");
</script><noscript><div><img src="https://mc.yandex.ru/watch/38589325" style="position:absolute; left:-9999px;" alt="" /></div></noscript>

</html>

